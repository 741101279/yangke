package com.crazymakercircle.im.common.exception;

/**
 * create by 尼恩 @ 疯狂创客圈
 **/
public class BusinessException extends RuntimeException
{

    public BusinessException(String s)
    {
        super(s);
    }
}
